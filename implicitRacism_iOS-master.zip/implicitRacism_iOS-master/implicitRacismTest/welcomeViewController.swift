//
//  welcomeViewController.swift
//  implicitRacismTest
//
//  Created by Nirbhay Singh on 30/05/20.
//  Copyright © 2020 Nirbhay Singh. All rights reserved.
//

import UIKit

class welcomeViewController: UIViewController {
    @IBOutlet weak var c1: NSLayoutConstraint!
    @IBOutlet weak var c2: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")
    }
    
}
